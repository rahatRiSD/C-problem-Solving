#include<bits/stdc++.h>
using namespace std;

int main()
{
    int t;
    cin>>t;
    while(t--)
    {
        long long int n,ans;
        cin>>n;
        ans=sqrt(n);
        cout<<ans<<endl;
    }
}
