#include<bits/stdc++.h>
using namespace std;

int main()
{
    int t;
    cin>>t;
    while(t--)
    {
        int n,m=0,k=0;
        cin>>n;
        int a[n];
        for(int i=0;i<n;i++)
        {
            cin>>a[i];
            if(a[i]%2==0){
                m+=a[i];
            }
            else k+=a[i];
        }
        if(m>k)cout<<"YES"<<endl;
        else cout<<"NO"<<endl;
    }
}
