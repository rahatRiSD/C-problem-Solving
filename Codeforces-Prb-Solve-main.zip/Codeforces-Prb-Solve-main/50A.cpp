#include<bits/stdc++.h>
using namespace std;

int main()
{
    int a,b,c,d;
    cin>>a>>b;
   cout<<(a*b/2)<<endl;
}
