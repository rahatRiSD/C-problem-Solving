#include<bits/stdc++.h>
using namespace std;
int main()
{
    int a,b,c,d;
    cin>>a;
    if(a%2==0)
    {
        cout<<a/2<<endl;
    }
    else
    {
        cout<<-((a/2)+1);
    }
}
