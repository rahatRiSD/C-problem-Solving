#include<bits/stdc++.h>
using namespace std;
int main()

{
    int n,t;
    char temp;
    string s;
    cin>>n;
    for(int j=0;j<n;j++)
    {
        cin>>t;
        for(int i=0;i<t;i++)
        {
            cin>>s[i];
            sort(s.begin(),s.end());
             if(s[i-1]=='a')cout<<1<<endl;
              if(s[i-1]=='b')cout<<2<<endl;
            if(s[i-1]=='c')cout<<3<<endl;
            if(s[i-1]=='d')cout<<4<<endl;
            if(s[i-1]=='e')cout<<5<<endl;
          if(s[i-1]=='f')cout<<6<<endl;
           if(s[i-1]=='g')cout<<7<<endl;
           if(s[i-1]=='h')cout<<8<<endl;
            if(s[i-1]=='i')cout<<9<<endl;
            if(s[i-1]=='j')cout<<10<<endl;
           if(s[i-1]=='k')cout<<11<<endl;
             if(s[i-1]=='l')cout<<12<<endl;
             if(s[i-1]=='m')cout<<13<<endl;
             if(s[i-1]=='n')cout<<14<<endl;
             if(s[i-1]=='o')cout<<15<<endl;
            if(s[i-1]=='p')cout<<16<<endl;
             if(s[i-1]=='q')cout<<17<<endl;
             if(s[i-1]=='r')cout<<18<<endl;
             if(s[i-1]=='s')cout<<19<<endl;
             if(s[i-1]=='t')cout<<20<<endl;
             if(s[i-1]=='u')cout<<21<<endl;
             if(s[i-1]=='v')cout<<22<<endl;
             if(s[i-1]=='w')cout<<23<<endl;
             if(s[i-1]=='x')cout<<24<<endl;
             if(s[i-1]=='y')cout<<25<<endl;
             if(s[i-1]=='z')cout<<26<<endl;









        }








    }

}

